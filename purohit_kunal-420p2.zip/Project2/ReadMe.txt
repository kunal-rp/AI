To Compile:

1) javac Main.java

2) java Main
