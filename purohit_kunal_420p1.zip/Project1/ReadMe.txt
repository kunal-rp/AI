Kunal Purohit
Project 1
CS 420

To Run:

1)Compile the Main.java File
  javac Main.java

2) Run the Main class file
  java main

The program will create/override the 'output.csv' file and generate the 150 randomly generated.

For the user inputted(and the randomly generated) puzzles, the program has the capability to change the desired goal puzzle.
Because of unclear instructions, the program has only been set to get the goal state of :

1 2 3
4 5 6
7 8 0
